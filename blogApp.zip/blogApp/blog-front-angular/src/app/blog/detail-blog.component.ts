import { Component,OnInit } from '@angular/core';
import { AppComponent } from '../app.component';
import { ActivatedRoute } from '@angular/router';

import { Comment } from '../models/comment.model';
import { Blog } from '../models/blog.model';
import { BlogService } from './blog.service';

@Component({
  templateUrl: './detail-blog.component.html',
  styleUrls: ['./detail-blog.component.css']
})
export class DetailBlogComponent  implements OnInit{

  blog: Blog = new Blog();
  comment: Comment = new Comment();
  listComments: Comment[];

  page = 1;
  pageSize = 60;
  collectionSize = 0;

  constructor(private appComponent: AppComponent,private blogService: BlogService,private route: ActivatedRoute,) {

  }
  
  
  ngOnInit() {
    const blogId = +this.route.snapshot.paramMap.get('id');

    if (blogId !== 0) {
        this.blogService.getBlog(blogId).subscribe(data => this.blog = data);
    	
    	this.getListComments(blogId);
    
    }
  }


   addComment(): void {
	    this.blogService.addComment(this.comment, this.blog.id)
	        .subscribe( data => {
	           this.appComponent.alsertClosed = false;
	           this.appComponent.alsertMessage = 'Comment has been added successfully.';
	           this.getListComments(this.blog.id);
	           this.comment.email="";
	           this.comment.message="";
	           this.comment.website="";
	        });
    }
    
 
 	get comments(): Comment[]   {
	     if (this.listComments != null) {
	            return  this.listComments.slice((this.page - 1) * this.pageSize, (this.page - 1) * this.pageSize + this.pageSize);
	
	     } else {
	        return  this.listComments; 
	     }

     }
     
     getListComments(blogId):void {
     	this.blogService.getComments(blogId)
		      .subscribe( data => {
		         this.listComments = data;
		         this.collectionSize = this.listComments.length;
		         
		         
         });
     }
     
     deleteComment(comment: Comment): void {
  
	   if (confirm('Are you sure you want to remove the comment ' + comment.id )) {
	   
		   this.blogService.deleteComment(comment)
		      .subscribe( data => {
		        this.listComments = this.listComments.filter(u => u !== comment);
		        this.collectionSize =  this.collectionSize -1;
		    })
	   }
  }

	 onSubmit() {
    	this.addComment();
  	}
}
