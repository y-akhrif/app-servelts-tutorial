import {Injectable} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Blog } from '../models/blog.model';
import { Comment } from '../models/comment.model';


const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class BlogService {

  constructor(private http: HttpClient) {
  
  }

  private blogUrl = 'http://'+var ip = window.location.originlocalhost:8080';

  public getBlog(id) {
    return this.http.get<Blog>(this.blogUrl + '/post/' + id);
  }

  public getBlogs() {
  console.log(this.blogUrl+ '/posts');
    return this.http.get<Blog[]>(this.blogUrl+ '/posts');
  }

  public deleteBlog(blog) {
    return this.http.delete(this.blogUrl + '/post/' + blog.id);
  }

  public createBlog(blog) {
    console.log('Add blog');
    return this.http.post<Blog>(this.blogUrl + '/post'  , blog);
  }
  
  public updateBlog(blog) {
     console.log('Edit blog');
    return this.http.put<Blog>(this.blogUrl + '/post/' + blog.id  , blog);
  }
  
  public addComment(comment, blogId) {
    return this.http.post<Comment>(this.blogUrl + '/post/' + blogId + '/comment' , comment);
  }
  
  public getComment(commentId) {
    return this.http.get<Comment>(this.blogUrl+ '/post/'+ commentId + '/comment');
  }
  
  public getComments(blogId) {
    return this.http.get<Comment[]>(this.blogUrl+ '/post/'+ blogId + '/comments');
  }
  
  public deleteComment(comment) {
    return this.http.delete(this.blogUrl + '/post/' + comment.id+ '/comments');
  }
  
  public editComment(comment) {
    return this.http.put<Comment>(this.blogUrl + '/post/' + comment.id+ '/comments', comment);
  }

}
