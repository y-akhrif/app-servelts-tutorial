import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { BlogComponent } from './blog/blog.component';
import {AddBlogComponent} from './blog/add-blog.component';
import {EditBlogComponent} from './blog/edit-blog.component';
import { DetailBlogComponent} from './blog/detail-blog.component';
import { EditCommentComponent} from './blog/edit-comment.component';


const routes: Routes = [
  { path: '', component: BlogComponent },
  { path: 'addBlog', component: AddBlogComponent },
  { path: 'editBlog/:id', component: EditBlogComponent },
  { path: 'blog/:id', component: DetailBlogComponent },
  { path: 'editComment/:commentId/:blogId', component: EditCommentComponent },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports: [
    RouterModule
  ],
  declarations: []
})
export class AppRoutingModule { }
