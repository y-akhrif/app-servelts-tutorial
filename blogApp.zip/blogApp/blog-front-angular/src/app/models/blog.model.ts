
export class Blog {

  id?: number;
  title: string;
  content: string;
  author: string;
  createdAt: string;
  updatedAt: string;
}
